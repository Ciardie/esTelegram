/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramapi;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author palazzolo_thomas
 */
public class test {

    private static String url = "https://api.telegram.org/bot";

    public test(String token) {
        url += token;
    }

    public ArrayList<message> getUpdates() throws IOException {
        chat chat;
        message mex;
        from from;

        ArrayList<message> messageList = new ArrayList<message>();
        URL fileUrl = new URL(url + "/getUpdates");
        Scanner inRemote = new Scanner(fileUrl.openStream());
        inRemote.useDelimiter("\u001a");
        String content = inRemote.next();
        String jsonString = content;
        JSONObject obj = new JSONObject(jsonString);
        JSONArray v = obj.getJSONArray("result");
        JSONObject mess, m, f, c;
        for (int i = 0; i < v.length(); i++) {
            mess = v.getJSONObject(i);
            m = mess.getJSONObject("message");
            f = m.getJSONObject("from");
            c = m.getJSONObject("chat");

            from = new from(f.getInt("id"), f.getBoolean("is_bot"), f.getString("first_name"), f.getString("username"), f.getString("language_code"));
            chat = new chat(c.getInt("id"), c.getString("first_name"), c.getString("username"), c.getString("type"));
            mex = new message(from, chat, mess.getInt("update_id"), m.getInt("message_id"), m.getInt("date"), m.getString("text"));

            messageList.add(mex);
        }
        return messageList;
    }

    public static void sendMessage(int idDestinatario, String testo) throws MalformedURLException, IOException {
        String urll = url + "/sendMessage?";
        String path = "chat_id=" + idDestinatario + "&text=" + URLEncoder.encode(testo, "UTF-8");
        URL fileUrl = new URL(urll + path);
        Scanner inRemote = new Scanner(fileUrl.openStream());
        inRemote.useDelimiter("\u001a");
        inRemote.close();
    }

//    public String leggi() throws FileNotFoundException, IOException {
//        URL fileUrl = new URL("");
//        Scanner inRemote = new Scanner(fileUrl.openStream());
//        inRemote.useDelimiter("\u001a");
//
//        String content = inRemote.next();
//        //PrintWriter wr = new PrintWriter("out.xml");
//        //wr.write(content);
//        //wr.close();
//        //inRemote.close();
//        return content;
//    }
}
