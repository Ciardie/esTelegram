/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramapi;

/**
 *
 * @author palazzolo_thomas
 */
public class message {

    public from from;
    public chat chat;
    public int update_id;
    public int idMsg;
    public int data;
    public String text;

    public message(from from, chat chat, int update_id, int message_id, int date, String text) {
        this.from = from;
        this.chat = chat;
        this.update_id = update_id;
        this.idMsg = message_id;
        this.data = date;
        this.text = text;
    }

    public message() {
    }
}
