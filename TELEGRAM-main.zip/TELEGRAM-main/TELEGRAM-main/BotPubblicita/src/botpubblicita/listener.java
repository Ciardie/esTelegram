/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botpubblicita;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import telegramapi.*;

/**
 *
 * @author User
 */
public class listener extends Thread{
    
    private test t;
    private String s;
    private ArrayList<message> msg = new ArrayList<message>();
    private int update_id = 0;

    public listener(test t, String s) {
        this.t = t;
        this.s = s;
    }

    public void run() {
        while (true) {
            try {
                msg = t.getUpdates();
            } catch (IOException ex) {
                Logger.getLogger(listener.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (msg.size() - 1 >= 0) {
                if (msg.get(msg.size() - 1).update_id != update_id)
                {//c'è un nuovo messaggio
                    update_id = msg.get(msg.size() - 1).update_id;
                    try{
                        analizza.analizza(msg.get(msg.size() - 1));
                    }catch(Exception e){
                    }
                }
            }
        }
    }
}
