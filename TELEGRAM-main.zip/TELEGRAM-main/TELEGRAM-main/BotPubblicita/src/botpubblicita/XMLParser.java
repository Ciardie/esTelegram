/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botpubblicita;

import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author palazzolo_thomas
 */
public class XMLParser {
    
    public XMLParser() {
    }

    public static ArrayList<location> parseDocument(String filename) throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Element root, element;
        NodeList nodelist;

        Document document;

        factory = DocumentBuilderFactory.newDefaultInstance();
        builder = factory.newDocumentBuilder();

        document = builder.parse(filename);
        root = document.getDocumentElement();

        nodelist = root.getElementsByTagName("place");
        ArrayList<location> lista = new ArrayList<location>();

        for (int i = 0; i < nodelist.getLength(); i++) {
            lista.add(parseLocation(nodelist.item(i)));
        }
        return lista;
    }

    public static location parseLocation(Node o) {
        return new location(Double.parseDouble(((Element)o).getAttribute("lat")), Double.parseDouble(((Element)o).getAttribute("lon")));
    }
}
