/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botpubblicita;

import TelegramAPI.*;
import org.json.*;

/**
 *
 * @author ciardiello_italo
 */
public class BotPubblicita {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        test j = new test();
        j.print();

        String jsonString = "{nome:'Mario', messaggio:[ciao, mondo]}"; //assign your JSON String here
        JSONObject obj = new JSONObject(jsonString);
        String pageName = obj.getString("nome");

        JSONArray arr = obj.getJSONArray("posts"); // notice that `"posts": [...]`
        for (int i = 0; i < arr.length(); i++) {
            String post_id = arr.getString(i);
        }
    }
}
